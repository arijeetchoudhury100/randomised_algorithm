itr = [];
piVal = [];
for i = 10:10:5000
  itr = [itr i];
  k = 0;
  for j = 1:i
    x = rand();
    y = rand();
    if (x*x + y*y) < 1
     k = k+1;
    end
  end
  piVal= [piVal 4*(k/i)];
end
disp(mean(piVal));
plot(itr,piVal);
title('Computing pi using Randomised algorithm');
xlabel('no. of iterations');
ylabel('value of pi');
grid on;