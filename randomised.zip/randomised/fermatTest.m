function prob = fermatTest(num,itr)
  count = 0;
  for i=1:itr
    a = randi(num);
    if (modpow(a,num-1,num) == 1)
      count++;
    end
  end
  prob = count/itr;
end

function result = modpow(a,n,p)
  result = 1;
  while n > 0
    if mod(n,2) == 1
      result = mod((result*a),p);
    end
    n = bitshift(n,-1);
    a =mod((a*a),p);
  end
end