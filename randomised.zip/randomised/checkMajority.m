function present = checkMajority(a,n,item)
  count = 0;
  val = floor(n/2);
  present = false;
  for i = 1:n
    if a(i) == item
      count = count+1;
    end
  end
  
  if count >= val
    present = true;
  end
end

    