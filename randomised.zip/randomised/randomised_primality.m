itr = zeros(1,100);
prob= zeros(1,100);
c = 1; 
%8-bit num = 191;
%10-bit num = 769
%12-bit num = 3251;
%14-bit num = 14341;
 num = 62303;

for i=10:10:1000
  itr(c) = i;
  prob(c) = fermatTest(num,i);
  c = c+1;    
end
plot(itr,prob);
xlabel("Number of Iterations");
ylabel("Probability of being prime");
grid on;