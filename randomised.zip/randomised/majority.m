a = [1,2,3,3,4,5,3,3,6,4,7,8,1,2,3,3,3,8,3,9,3,1,3,3,3,]
p = false;
n = length(a);
k = 0;
%repeat for 10 times
for i=1:10
  idx = randi(n);
  p = checkMajority(a,n,a(idx)); %randomly pick an element and check if it is the majority element
  if p ==true
    disp('majority element exists');
    disp(a(idx));
    break;
  else
    k = k+1;
  end
end


