a = [1,2,3,3,4,5,3,3,6,4,7,8,1,2,3,3,3,8,3,9,3,1,3,3,3,];
n = length(a);
itr = [];
prob_miss = [];
%repeat for 10 times
for i=10:10:2000
  k = 0;
  p = false;
  itr = [itr i];
  for j=1:i
    idx = randi(n);
    p = checkMajority(a,n,a(idx)); %randomly pick an element and check if it is the majority element
    if p == true
     break;
    else
      k = k+1;
    end
  end
  prob_miss =[prob_miss k/i];
end
disp(mean(prob_miss));
plot(itr,prob_miss);
title('Majority element in an array');
xlabel('no. of iterations');
ylabel('missing probability');
grid on;